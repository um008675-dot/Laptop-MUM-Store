# MUM Store - Core i9 RTX 4070 Gaming Laptop Landing Page

A single-page landing page (HTML, CSS and JavaScript in one file) for selling a Core i9 gaming laptop in Pakistan and worldwide.

## Files
- `index.html` - the full landing page

## Edit your details
Open `index.html` and find the `EDIT THESE` block near the bottom of the script:
- `WA` - WhatsApp number with country code
- `RATE` - PKR per USD
- `STOCK` - real units left
- `OFFER_END` - real offer end date
- `EMAIL`, `ADDRESS` - footer contact details
- `REVIEWS` - real customer reviews
- `IMG` - product photos (replace with your own file paths)

## Publish with GitHub Pages
Repo Settings > Pages > Deploy from a branch > `main` / root.
